package com.example.effortlogger;

public class Activity {
    /**
     * The basic unit of work in EffortLogger.
     * When the "Start an Activity" button is pressed, one of these is created.
     * The start time and descriptors are added as they are known.
     * When the user clicks "Stop this Activity", the end time is updated and the
     * activity is passed to the log
     **/
    private String startTime;
    private String endTime;
    private String project;
    private String lifeCycleStep;
    private String effortCategory;
    private String effortCategoryElaborated;

    public Activity(String startTime, String endTime, String project, String lifeCycleStep, String effortCategory,
            String effortCategoryElaborated) {
        this.startTime = startTime;
        this.endTime = endTime;
        this.project = project;
        this.lifeCycleStep = lifeCycleStep;
        this.effortCategory = effortCategory;
        this.effortCategoryElaborated = effortCategoryElaborated;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    public String getProject() {
        return project;
    }

    public void setProject(String project) {
        this.project = project;
    }

    public String getLifeCycleStep() {
        return lifeCycleStep;
    }

    public void setLifeCycleStep(String lifeCycleStep) {
        this.lifeCycleStep = lifeCycleStep;
    }

    public String getEffortCategory() {
        return effortCategory;
    }

    public void setEffortCategory(String effortCategory) {
        this.effortCategory = effortCategory;
    }

    public String getEffortCategoryElaborated() {
        return effortCategoryElaborated;
    }

    public void setEffortCategoryElaborated(String effortCategoryElaborated) {
        this.effortCategoryElaborated = effortCategoryElaborated;
    }
}