package com.example.effortlogger;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Implemented by Aleksandr Cooper - 1219177947
 * Can be utilized on any text field where the user is asked for input
 * This object/function checks that no special characters are contained in the
 * user input passed to it
 * This prevents logical hacks from gaining unauthorized access to the system
 * Low overhead using regular expressions rather than looping through every
 * possible character
 */
public class UserInputSecurity {

    // If any non-alphanumeric characters are entered, this function will return
    // true
    public boolean containsIllegalCharacters(String input) {
        Pattern pattern = Pattern.compile("[^a-zA-Z0-9]");
        Matcher matcher = pattern.matcher(input);
        return matcher.find();
    }
}
