package com.example.effortlogger;

import javafx.fxml.FXML;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.util.Callback;

public class LogView {

    public ListView<Activity> activityListDisplay;

    @FXML // This method is called by the FXMLLoader when initialization is complete
    void initialize() {

    }

    public void refreshList() {
        ObservableList<Activity> listToDisplay = FXCollections.observableArrayList(GlobalActivityArray.activityList);
        activityListDisplay.setItems(listToDisplay);
        activityListDisplay.setCellFactory(new Callback<ListView<Activity>, ListCell<Activity>>() {
            @Override
            public ListCell<Activity> call(ListView<Activity> listView) {
                return new ListCell<Activity>() {
                    @Override
                    protected void updateItem(Activity activity, boolean empty) {
                        super.updateItem(activity, empty);
                        if (activity == null || empty) {
                            setText(null);
                        } else {
                            System.out.println("Populating List\n");
                            setText(activity.getStartTime() + " - " + activity.getEndTime() + " - "
                                    + activity.getProject());
                        }
                    }
                };
            }
        }); // End CellFactory
    }
}