package com.example.effortlogger;

public class GlobalActivityArray {
    /**
     * This is the project-wide list for all activities
     * Right now, it is volatile.
     * Ultimately this should be read out to a text file and then imported in and
     * populated each time the software is opened
     */
    // TODO: Write contents of this array to a (encrypted?) file when software
    // closed, read back in when opened
    public static Activity[] activityList = new Activity[100]; // Default size, subject to change...
    public static int nextEmpty = 0; // Location of next empty slot in the array -- increment whenever adding,
                                     // decrement when removing

    public static void incrementNextEmpty() {
        nextEmpty++;
        System.out.println("Pointer Incremented\n");
    }
}