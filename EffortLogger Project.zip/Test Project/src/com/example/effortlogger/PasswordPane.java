package com.example.effortlogger;
//package application;

import java.io.IOException;
import java.util.LinkedList;
//import java.util.ListIterator;
import java.util.Objects;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.Parent;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.fxml.FXMLLoader;

/**
 * Password Pane by Bryson Martin
 * Aligns with security requirements by necessitating users to be granted
 * authorization
 * Users are unable to gain entry into the system without verified credentials
 * -- goal achieved
 */
public class PasswordPane extends Application {
    @FXML
    public Button finalizeCredentials;
    @FXML
    public Button createAcc;
    // Declare Account LinkedList
    private final LinkedList<Account> accountList = new LinkedList<>();
    // Declare Login Elements
    public Stage stage;
    public TextField userText = new TextField();
    public Label userLabel = new Label();
    public TextField passText = new TextField();
    public PasswordField loginpassText = new PasswordField();
    public Label passLabel = new Label();
    private final Button loginbtn = new Button();
    private final Button createacc = new Button();
    @FXML
    public Label attemptsCounterTxt = new Label("");

    @FXML
    public void initialize() {
        attemptsCounterTxt.setText("");
    }
    // public ListIterator<Account> accountIterator = accountList.listIterator();

    /**
     * Login Tracking System - Aleksandr Cooper
     * When the failed login counter reaches a certain value, the system will close
     * This increases security since a brute force password program would not be
     * able to succeed
     * The number of failed attempts will eventually be parameterizable, default to
     * 5 attempts for demonstration purposes
     */
    private int failedLogins;
    private int maxAllowedFailedLogins = 5;

    public Account testAcc = new Account("admin", "12345");

    // Declare Scenes
    public Scene scene;

    // Addition variables
    int counter = 0;

    /*
     * InActivity System - Bryson Martin
     * When a user does not make an action for 8 minutes you will receive a warning
     * that
     * you will be logged out. At 15 minutes an error message will be sent and the
     * user
     * will automatically be logged out.
     */
    public static long lastMouseMovedTime = System.currentTimeMillis() / 1000;
    private static final int IDLE_TIME_THRESHOLD = 10; // in seconds 15 minute idle time
    public boolean warningOpen = false;
    public boolean timeoutOpen = false;

    public void start(Stage stage) throws IOException {
        this.stage = stage;
        // add testAcc to linked-list
        accountList.add(testAcc);
        // redundant declarations
        userLabel.setText("Username (admin for demo)");
        passLabel.setText("Password (12345 for demo)");
        loginbtn.setText("Login");
        createacc.setText("Create Account");
        // Reset failed logins
        attemptsCounterTxt.setText("");
        failedLogins = 0;
        maxAllowedFailedLogins = 5;
        // Loads initial login window
        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("LoginPane.fxml")));
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();

        System.out.print(accountList.getFirst());
        // Method to handle user activity and timesout the user when no action is made
        // for:
        Timeline timeline = new Timeline(new KeyFrame(javafx.util.Duration.seconds(1), new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                // Get the current time in seconds
                long currentTime = System.currentTimeMillis() / 1000;

                // Calculate the idle time
                long idleTime = currentTime - lastMouseMovedTime;

                // Check if the idle time exceeds the threshold
                if (idleTime * 2 > IDLE_TIME_THRESHOLD && warningOpen == false) {
                    warningOpen = true;
                    Stage newStage = new Stage();
                    FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("TimeoutWarning.fxml"));
                    Scene warningScene;
                    try {
                        warningScene = new Scene(fxmlLoader.load(), 600, 400);
                        newStage.setScene(warningScene);
                        newStage.show();
                        StageManager.addStage(newStage);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                if (idleTime > IDLE_TIME_THRESHOLD && timeoutOpen == false) {
                    timeoutOpen = true;
                    Stage newStage = new Stage();
                    FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("Timeout.fxml"));
                    Scene scene;
                    try {
                        scene = new Scene(fxmlLoader.load(), 600, 400);
                        newStage.setScene(scene);
                        newStage.show();
                        StageManager.addStage(newStage);
                        stage.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        }));
        timeline.setCycleCount(Timeline.INDEFINITE);
        timeline.play();

        scene.setOnMouseMoved(e -> {
            // Update the last mouse moved time
            lastMouseMovedTime = System.currentTimeMillis() / 1000;
        });

        scene.setOnKeyPressed(e -> {
            lastMouseMovedTime = System.currentTimeMillis() / 1000;
        });

        scene.setOnMouseClicked(e -> {
            lastMouseMovedTime = System.currentTimeMillis() / 1000;
        });
    }

    // This event triggers when the OK button is pressed on the warning screen
    public void ackowledgeWarning(ActionEvent event) throws IOException {
        warningOpen = false;
        Stage currentStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        currentStage.close();
    }

    // This event triggers when the OK button is pressed on the timeout screen
    public void ackowledgeTimeout(ActionEvent event) throws IOException {
        Stage currentStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Stage newStage = new Stage();
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("LoginPane.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 600, 400);
        newStage.setScene(scene);
        newStage.show();
        currentStage.close();
        StageManager.closeAllStages();

    }

    // Event triggers when login button is pressed on login page - Bryson
    public void LoginAttempted(ActionEvent event) throws IOException {
        // Account tAcc = new Account(userText.getText(), loginpassText.getText());
        System.out.println(testAcc.getUserName());
        System.out.println(testAcc.getPassword());
        UserInputSecurity security = new UserInputSecurity();
        boolean badPassword = security.containsIllegalCharacters(loginpassText.getText());
        boolean badUsername = security.containsIllegalCharacters(userText.getText());
        // Check Username & Password For Illegal Characters - Aleks
        // Count number of failed attempts - Aleks
        if (failedLogins < maxAllowedFailedLogins - 1) {
            if (badPassword || badUsername) {
                System.out.println("Password or Username contains illegal characters");
                failedLogins++;
                attemptsCounterTxt.setText(
                        "Incorrect Credentials. " + (maxAllowedFailedLogins - failedLogins) + " attempts remaining");
            } else {
                if (Objects.equals(userText.getText(), testAcc.getUserName())
                        && Objects.equals(loginpassText.getText(), testAcc.getPassword())) {
                    System.out.println("Login Success");
                    // passes login button press to switchToEffortConsole method -Bryson
                    switchToEffortConsole(event);
                } else {
                    failedLogins++;
                    attemptsCounterTxt.setText("Incorrect Credentials. " + (maxAllowedFailedLogins - failedLogins)
                            + " attempts remaining");
                    System.out.println("Login Failed");
                }
            }
        } else {
            // Too many failed attempts, close the program
            Stage currentStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            currentStage.close();
        }
    }

    // Event triggers when Log in button is pressed and user credentials have been
    // validated - Bryson
    public void switchToEffortConsole(ActionEvent event) throws IOException {
        Stage currentStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        // Stage newStage = new Stage();
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("EffortConsole-view.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 1100, 700);
        currentStage.setScene(scene);
        // Show the new window
        // newStage.show();
        // StageManager.addStage(newStage);
        // Close the current window
        // currentStage.close();
        scene.setOnMouseMoved(e -> {
            // Update the last mouse moved time
            System.out.println("Mouse Moved");
            lastMouseMovedTime = System.currentTimeMillis() / 1000;
        });

        scene.setOnKeyPressed(e -> {
            lastMouseMovedTime = System.currentTimeMillis() / 1000;

        });

        scene.setOnMouseClicked(e -> {
            lastMouseMovedTime = System.currentTimeMillis() / 1000;

        });
    }

    // Event triggers when Create Account button is pressed - Bryson
    public void switchToCreateAccScene(ActionEvent event) throws IOException {
        Stage currentStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        // Stage newStage = new Stage();
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("CreateAccountPane.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 600, 400);
        currentStage.setScene(scene);
        // newStage.setScene(scene);
        // Show the new window
        // newStage.show();
        // Close the current window
        // currentStage.close();
        scene.setOnMouseMoved(e -> {
            // Update the last mouse moved time
            lastMouseMovedTime = System.currentTimeMillis() / 1000;
        });

        scene.setOnKeyPressed(e -> {
            lastMouseMovedTime = System.currentTimeMillis() / 1000;

        });

        scene.setOnMouseClicked(e -> {
            lastMouseMovedTime = System.currentTimeMillis() / 1000;

        });
    }

    // Event triggers when Finalize Credentials button is pressed on Create Account
    // - Bryson
    // page
    public void AccountCreated(ActionEvent event) throws IOException {
        UserInputSecurity security = new UserInputSecurity();
        boolean badPassword = security.containsIllegalCharacters(passText.getText());
        boolean badUsername = security.containsIllegalCharacters(userText.getText());

        // Check Username & Password For Illegal Characters - Aleks
        if (badPassword || badUsername) {
            System.out.println("Password or Username contains illegal characters");
        } else {
            Account newAcc = new Account(userText.getText(), passText.getText());
            System.out.println("Username:" + userText.getText());
            System.out.println("Password:" + passText.getText());
            System.out.println(newAcc.getUserName());
            System.out.println(newAcc.getPassword());
            accountList.add(newAcc);
            counter++;
            // passes finalize credentials button press to switchToLoginScene method -
            // Bryson
            switchToLoginScene(event);
        }
    }

    public void switchToLoginScene(ActionEvent event) throws IOException {
        // Stage currentStage = (Stage) finalizeCredentials.getScene().getWindow();
        Stage currentStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        // Stage newStage = new Stage();
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("LoginPane.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 600, 400);
        currentStage.setScene(scene);
        // newStage.setScene(scene);
        // Show the new window
        // newStage.show();
        // Close the current window
        // currentStage.close();

        scene.setOnMouseMoved(e -> {
            // Update the last mouse moved time
            lastMouseMovedTime = System.currentTimeMillis() / 1000;
        });

        scene.setOnKeyPressed(e -> {
            lastMouseMovedTime = System.currentTimeMillis() / 1000;

        });

        scene.setOnMouseClicked(e -> {
            lastMouseMovedTime = System.currentTimeMillis() / 1000;

        });
    }

    public static void main(String[] args) {
        launch(args);
    }
}