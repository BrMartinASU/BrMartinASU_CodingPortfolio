package com.example.effortlogger;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.CornerRadii;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.io.IOException;

public class EffortConsoleView {
    String project = "No Project Selected";
    String lifeCycleStep = "No Life Cycle Step Selected";
    String effortCategory = "No Effort Category Selected";
    String specificEffortCategory = "No Specific Category Selected";
    boolean projectRunning = false;
    boolean projectFinished = true;
    LocalDateTime startTime;
    String formattedStartTime;
    LocalDateTime endTime;
    String formattedEndTime;
    @FXML
    public Label effortCategoryDisplay;
    @FXML
    public ChoiceBox<String> selectProject;
    @FXML
    public ChoiceBox<String> selectLifeCycleStep;
    @FXML
    public ChoiceBox<String> selectEffortCategory;
    @FXML
    public ChoiceBox<String> selectSpecificEffortCategory;

    @FXML
    private Label clockIndicator;
    @FXML
    private Button viewLogBtn;
    private static long lastMouseMovedTime;

    @FXML // This method is called by the FXMLLoader when initialization is complete
    void initialize() {

    }

    public void onActivityStarted() {
        if (!projectRunning) {
            projectFinished = false;
            projectRunning = true;

            // Set background green
            BackgroundFill backgroundFill = new BackgroundFill(Color.GREEN, CornerRadii.EMPTY, Insets.EMPTY);
            Background background = new Background(backgroundFill);
            clockIndicator.setBackground(background);
            clockIndicator.setText("Clock is Running");

            // Start the clock
            startTime = LocalDateTime.now();
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
            formattedStartTime = startTime.format(formatter);
            System.out.println(formattedStartTime + "\n");

            // Alter UI
            selectEffortCategory.valueProperty()
                    .addListener((observable, oldValue, newValue) -> effortCategoryDisplay.setText(newValue));

        } else {
            // User clicked start activity before stopping the current activity
            System.out.println("Task already running!\n");
        }
    }

    public void onActivityStopped() {
        if (!projectFinished) {
            projectRunning = false;
            projectFinished = true;

            // Set background red
            BackgroundFill backgroundFill = new BackgroundFill(Color.RED, CornerRadii.EMPTY, Insets.EMPTY);
            Background background = new Background(backgroundFill);
            clockIndicator.setBackground(background);
            clockIndicator.setText("Clock is Stopped");

            // Get the values from the menu boxes
            if (selectProject.getValue() != null) {
                project = selectProject.getValue();
            }
            if (selectLifeCycleStep.getValue() != null) {
                lifeCycleStep = selectLifeCycleStep.getValue();
            }
            if (selectEffortCategory.getValue() != null) {
                effortCategory = selectEffortCategory.getValue();
            }
            if (selectSpecificEffortCategory.getValue() != null) {
                specificEffortCategory = selectSpecificEffortCategory.getValue();
            }

            // Stop the clock
            endTime = LocalDateTime.now();
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
            formattedEndTime = endTime.format(formatter);

            // Create new Activity object and add it to the global array
            GlobalActivityArray.activityList[GlobalActivityArray.nextEmpty] = new Activity(formattedStartTime,
                    formattedEndTime, project, lifeCycleStep, effortCategory, specificEffortCategory);
            GlobalActivityArray.incrementNextEmpty(); // Increment pointer to next empty slot
        } else {
            // User clicked stop activity before clicking start activity
            System.out.println("No ongoing tasks to complete!\n");
        }
    }

    public void viewLog() throws IOException {
        Stage currentStage = (Stage) viewLogBtn.getScene().getWindow();
        // Stage newStage = new Stage();
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("Log-view.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 600, 400);
        // newStage.setScene(scene);
        currentStage.setScene(scene);
        // Show the new window
        // newStage.show();
        // StageManager.addStage(newStage);
        // Close the current window
        // currentStage.close();
        scene.setOnMouseMoved(e -> {
            // Update the last mouse moved time
            System.out.println("Mouse Moved");
            lastMouseMovedTime = System.currentTimeMillis() / 1000;
        });

        scene.setOnKeyPressed(e -> {
            lastMouseMovedTime = System.currentTimeMillis() / 1000;
            System.out.println("Key Pressed");
        });

        scene.setOnMouseClicked(e -> {
            lastMouseMovedTime = System.currentTimeMillis() / 1000;
            System.out.println("Mouse Clicked");
        });
    }
}