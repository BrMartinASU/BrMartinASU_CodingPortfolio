package com.example.effortlogger;
//package application;

public class Account {
    private String username;
    private String password;

    public Account() {
        username = "?";
        password = "?";
    }

    public Account(String name, String pass) {
        username = name;
        password = pass;
    }

    public String getUserName() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public void setUserName(String name) {
        username = name;
    }

    public void setPassword(String pass) {
        password = pass;
    }
}
