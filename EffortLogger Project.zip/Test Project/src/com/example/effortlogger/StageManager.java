package com.example.effortlogger;

import javafx.stage.Stage;
import java.util.ArrayList;
import java.util.List;

public class StageManager {

    public static final List<Stage> stages = new ArrayList<>();

    public static void addStage(Stage stage) {
        stages.add(stage);
    }

    public static void closeAllStages() {
        for (Stage stage : stages) {
            stage.close();
        }
    }
}
