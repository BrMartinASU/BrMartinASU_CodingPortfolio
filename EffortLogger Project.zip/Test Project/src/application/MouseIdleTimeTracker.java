package application;

import java.io.IOException;
import javafx.fxml.FXMLLoader;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;
import javafx.scene.Node;
import javafx.util.Duration;

public class MouseIdleTimeTracker extends Application {

    // Set the idle time threshold in seconds (e.g. 5 minutes)
    private static final int IDLE_TIME_THRESHOLD = 5;

    // Store the time of the last mouse movement
    private long lastMouseMovedTime = System.currentTimeMillis() / 1000;

    // public Stage primaryStage;
    // public Stage currentStage = new Stage();
    private boolean warningOpen = false;
    private boolean timeoutOpen = false;

    @Override
    public void start(Stage primaryStage) {
        // Label idleTimeLabel = new Label("Idle Time: 0 seconds");

        Timeline timeline = new Timeline(new KeyFrame(Duration.seconds(1), new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                // Get the current time in seconds
                long currentTime = System.currentTimeMillis() / 1000;

                // Calculate the idle time
                long idleTime = currentTime - lastMouseMovedTime;

                // Update the idle time label
                // idleTimeLabel.setText("Idle Time: " + idleTime + " seconds");

                // Check if the idle time exceeds the threshold
                if (idleTime * 2 > IDLE_TIME_THRESHOLD && warningOpen == false) {
                    /*
                     * TODO: write a warning message to be displayed here
                     * also close the window once the OK button has been pressed
                     */
                    // currentStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
                    warningOpen = true;
                    Stage newStage = new Stage();
                    FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("TimeoutWarning.fxml"));
                    Scene warningScene;
                    try {
                        warningScene = new Scene(fxmlLoader.load(), 600, 400);
                        newStage.setScene(warningScene);
                        newStage.show();
                    } catch (IOException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                }
                if (idleTime > IDLE_TIME_THRESHOLD && timeoutOpen == false) {
                    timeoutOpen = true;
                    Stage newStage = new Stage();
                    FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("Timeout.fxml"));
                    Scene scene;
                    try {
                        scene = new Scene(fxmlLoader.load(), 600, 400);
                        newStage.setScene(scene);
                        newStage.show();
                        primaryStage.close();
                    } catch (IOException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                }
            }
        }));
        timeline.setCycleCount(Timeline.INDEFINITE);
        timeline.play();

        StackPane root = new StackPane();
        // root.getChildren().add(idleTimeLabel);

        Scene scene = new Scene(root, 300, 250);

        scene.setOnMouseMoved(e -> {
            // Update the last mouse moved time
            lastMouseMovedTime = System.currentTimeMillis() / 1000;
        });

        primaryStage.setScene(scene);
        primaryStage.show();
    }

    // This event triggers when the OK button is pressed on the warning screen
    public void ackowledgeWarning(ActionEvent event) throws IOException {
        warningOpen = false;
        Stage currentStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        currentStage.close();
    }

    // This event triggers when the OK button is pressed on the timeout screen
    public void ackowledgeTimeout(ActionEvent event) throws IOException {
        Stage currentStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Stage newStage = new Stage();
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("LoginPane.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 600, 400);
        newStage.setScene(scene);
        newStage.show();
        currentStage.close();

    }

    public static void main(String[] args) {
        launch(args);
    }
}
