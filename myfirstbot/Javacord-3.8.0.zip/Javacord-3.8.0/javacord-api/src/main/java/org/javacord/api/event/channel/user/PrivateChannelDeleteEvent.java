package org.javacord.api.event.channel.user;

/**
 * A private channel delete event.
 */
public interface PrivateChannelDeleteEvent extends PrivateChannelEvent {
}
