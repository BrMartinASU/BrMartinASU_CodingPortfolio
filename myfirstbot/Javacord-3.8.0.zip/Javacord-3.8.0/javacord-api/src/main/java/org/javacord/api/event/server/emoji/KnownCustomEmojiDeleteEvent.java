package org.javacord.api.event.server.emoji;

/**
 * A custom emoji delete event.
 */
public interface KnownCustomEmojiDeleteEvent extends KnownCustomEmojiEvent {
}
