package org.javacord.api.event.message;

/**
 * A message delete event.
 */
public interface MessageDeleteEvent extends OptionalMessageEvent {
}
