package org.javacord.api.event.server.member;

/**
 * A server member join event.
 */
public interface ServerMemberJoinEvent extends ServerMemberEvent {
}
