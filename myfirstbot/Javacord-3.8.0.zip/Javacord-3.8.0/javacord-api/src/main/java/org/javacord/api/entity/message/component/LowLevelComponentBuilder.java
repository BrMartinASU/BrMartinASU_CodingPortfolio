package org.javacord.api.entity.message.component;

public interface LowLevelComponentBuilder extends ComponentBuilder {
}
