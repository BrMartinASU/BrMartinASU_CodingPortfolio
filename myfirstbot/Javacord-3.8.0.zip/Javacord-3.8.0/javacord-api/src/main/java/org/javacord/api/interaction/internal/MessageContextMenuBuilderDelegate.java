package org.javacord.api.interaction.internal;

import org.javacord.api.interaction.MessageContextMenu;

public interface MessageContextMenuBuilderDelegate extends ApplicationCommandBuilderDelegate<MessageContextMenu> {
}
