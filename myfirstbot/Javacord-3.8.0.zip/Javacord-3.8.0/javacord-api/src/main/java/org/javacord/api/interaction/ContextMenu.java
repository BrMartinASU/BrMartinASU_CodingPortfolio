package org.javacord.api.interaction;

public interface ContextMenu extends ApplicationCommand {
}
