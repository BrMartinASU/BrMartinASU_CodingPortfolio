package org.javacord.api.event.server.sticker;

/**
 * A sticker create event.
 */
public interface StickerCreateEvent extends StickerEvent {
}
