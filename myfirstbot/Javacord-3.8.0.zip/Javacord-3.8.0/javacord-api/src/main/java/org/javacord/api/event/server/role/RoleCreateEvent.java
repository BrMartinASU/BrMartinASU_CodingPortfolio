package org.javacord.api.event.server.role;

/**
 * A role create event.
 */
public interface RoleCreateEvent extends RoleEvent {
}
