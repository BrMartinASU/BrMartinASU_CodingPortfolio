package org.javacord.api.entity.message.component;

public interface HighLevelComponentBuilder extends ComponentBuilder {
}
