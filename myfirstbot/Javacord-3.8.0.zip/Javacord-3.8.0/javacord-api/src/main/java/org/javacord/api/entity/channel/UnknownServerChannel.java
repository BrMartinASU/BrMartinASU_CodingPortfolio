package org.javacord.api.entity.channel;

import org.javacord.api.entity.Mentionable;

/**
 * This class represents an unknown server channel.
 */
public interface UnknownServerChannel extends ServerChannel, Mentionable {

}
