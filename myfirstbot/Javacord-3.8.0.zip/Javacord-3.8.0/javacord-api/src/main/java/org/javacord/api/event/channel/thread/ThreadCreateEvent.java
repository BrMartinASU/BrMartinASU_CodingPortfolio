package org.javacord.api.event.channel.thread;

import org.javacord.api.event.channel.server.ServerChannelEvent;

public interface ThreadCreateEvent extends ServerChannelEvent {

}
