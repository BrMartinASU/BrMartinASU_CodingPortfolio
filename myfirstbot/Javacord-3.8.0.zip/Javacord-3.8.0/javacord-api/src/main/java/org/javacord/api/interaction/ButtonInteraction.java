package org.javacord.api.interaction;

public interface ButtonInteraction extends MessageComponentInteractionBase {
}
