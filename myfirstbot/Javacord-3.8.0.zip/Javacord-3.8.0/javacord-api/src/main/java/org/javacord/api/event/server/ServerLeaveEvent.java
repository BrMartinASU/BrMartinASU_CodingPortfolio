package org.javacord.api.event.server;

/**
 * A server leave event.
 */
public interface ServerLeaveEvent extends ServerEvent {
}
