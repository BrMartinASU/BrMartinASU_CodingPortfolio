package org.javacord.api.event.message.reaction;

/**
 * A reaction remove event.
 */
public interface ReactionRemoveEvent extends SingleReactionEvent {
}
