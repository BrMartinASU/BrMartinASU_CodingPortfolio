package org.javacord.api.entity.message.mention;

public enum AllowedMentionType {

    USERS,
    ROLES,
    EVERYONE;

}
