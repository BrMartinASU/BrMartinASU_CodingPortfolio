package org.javacord.api.event.server.member;

/**
 * A server member leave event.
 */
public interface ServerMemberLeaveEvent extends ServerMemberEvent {
}
