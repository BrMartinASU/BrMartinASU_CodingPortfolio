package org.javacord.api.entity.channel;

import org.javacord.api.entity.Mentionable;

/**
 * This class represents an unknown regular server channel.
 */
public interface UnknownRegularServerChannel extends RegularServerChannel, Mentionable {

}
