package org.javacord.api.event.server;

/**
 * A server join event.
 */
public interface ServerJoinEvent extends ServerEvent {
}
