package org.javacord.api.event.message;

/**
 * A message create event.
 */
public interface MessageCreateEvent extends CertainMessageEvent {
}
