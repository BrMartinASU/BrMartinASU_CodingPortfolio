package org.javacord.api.event.server.role;

/**
 * A user role add event.
 */
public interface UserRoleAddEvent extends UserRoleEvent {
}
