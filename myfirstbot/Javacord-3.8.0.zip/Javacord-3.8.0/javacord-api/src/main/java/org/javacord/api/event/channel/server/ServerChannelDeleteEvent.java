package org.javacord.api.event.channel.server;

/**
 * A server channel delete event.
 */
public interface ServerChannelDeleteEvent extends ServerChannelEvent {
}
