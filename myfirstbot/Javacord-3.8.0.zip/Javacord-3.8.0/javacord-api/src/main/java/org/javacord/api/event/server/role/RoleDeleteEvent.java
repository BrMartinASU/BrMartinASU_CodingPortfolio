package org.javacord.api.event.server.role;

/**
 * A role delete event.
 */
public interface RoleDeleteEvent extends RoleEvent {
}
