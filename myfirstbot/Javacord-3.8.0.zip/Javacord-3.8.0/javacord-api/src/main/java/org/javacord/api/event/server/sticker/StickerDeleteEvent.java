package org.javacord.api.event.server.sticker;

/**
 * A sticker delete event.
 */
public interface StickerDeleteEvent extends StickerEvent {
}
